﻿/// <reference path="_references.js">
$(document).ready(function () {
    drawPattern();
});
function drawPattern() {
	var canvas = document.getElementById('myCanvas')
	, ctx = canvas.getContext('2d');
	// create new image object to use as pattern
	var img = new Image();
	img.src = 'images/pattern.gif';
	img.onload = function () {
	// create pattern
	var ptrn = ctx.createPattern(img, 'repeat');
		ctx.fillStyle = ptrn;
		ctx.fillRect(0, 0, 400, 400);
	}
}