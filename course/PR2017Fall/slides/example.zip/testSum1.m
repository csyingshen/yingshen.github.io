nn = [0:10]; % vector of values of n (nn) 
m = length(nn); % length of vector nn 
SS = []; % initialize vector SS as an empty matrix 
for j = 1:m % This loop fills out the vector SS 
    SS = [SS sum1(nn(j))]; % with values calculated 
end % from function sum1(n) 
plot(nn,SS) % show results in graphical format 
