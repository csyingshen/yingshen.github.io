n = 100;
x = 2*pi*(0:n-1)'/(n-1);
y1 = sin(x);
y2 = exp(cos(x));
figure;
plot(x,y1);
hold on;
%figure;
plot(x,y2);
