 function [S] = sum1(n) 
% |----------------------------------------| 
% | This function calculates the summation | 
% |                                        | 
% |                                   n    | 
% |                             \--------- | 
% |                              \    1    | 
% |                        S(n) = \ _____  | 
% |                               /   2    | 
% |                              /   k + 1 | 
% |                             /--------- | 
% |                                 k = 0  | 
% | | 
% |----------------------------------------| 
S = 0; % Initialize sum to zero 
k = 0; % Initialize index to zero 
% loop for calculating summation 
while k <= n 
    S = S + 1/(k^2+1); % add to summation 
    k = k + 1; % increase the index 
end 
