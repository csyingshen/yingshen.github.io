function [f,g] = linear_regression(theta, X,y)
  %
  % Arguments:
  %   theta - A vector containing the parameter values to optimize.
  %   X - The examples stored in a matrix.
  %       X(i,j) is the i'th coordinate of the j'th example.
  %   y - The target value for each example.  y(j) is the target for example j.
  %f is the cost 
  %g is a column vector, representing the gradient of the cost function to
  %theta
 
  f = sum((theta'*X - y).^2) * 0.5;
  % Compute the gradient of the objective with respect to theta by looping over
  % the examples in X and adding up the gradient for each example.  Store the
  % computed gradient in 'g'.
  thetaMultiplyXMinusy = theta'*X-y;
  g = sum(bsxfun(@times,thetaMultiplyXMinusy, X),2);
