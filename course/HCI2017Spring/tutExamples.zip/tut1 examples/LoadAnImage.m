A = imread('moonwalk.jpg');
image(A);