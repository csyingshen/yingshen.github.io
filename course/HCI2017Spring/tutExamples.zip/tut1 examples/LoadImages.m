img = cell(4,1);
for i = 1:4
    img{i} = imread(['bg' num2str(i) '.png']);
end
hold on;
image(0,0,img{1});
image(200, 0, img{2});
image(0,100,img{3});
image(200,100,img{4});