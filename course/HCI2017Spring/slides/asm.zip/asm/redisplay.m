function redisplay;
% Redisplay things when slider values are changed

% WhatToRedisplay specifies a three nb vector 
% [1 0 0] to repaint only axes X
% and so on. To avoid working too much

% Must be issued in all functions using the global variable
global allslices;

[xs,ys,zs]=size(allslices);

% Get the handle of the figure
figure(findobj('Tag','Mainfig'))

% The slider does not come with integer values, so fetch them to integers
val_x = ceil(get(findobj('Tag','slider_X'),'Value')-0.5);
val_y = ceil(get(findobj('Tag','slider_Y'),'Value')-0.5);
val_z = ceil(get(findobj('Tag','slider_Z'),'Value')-0.5);

% Draw the right slice at the right place
% and with pretty yellow lines showing where we are

	subplot(2,2,1)
		oneslicez=allslices(:,:,val_z)';
		image(oneslicez)%,'Erasemode','none') 
		title('Z slice');
		xlabel('x-axis');
		ylabel('y-axis');
      l=line([1,xs],[val_y,val_y]);set(l,'Color',[1 1 0])
		l=line([val_x,val_x],[1,ys]);set(l,'Color',[1 1 0])
   
	subplot(2,2,2);
		oneslicex=reshape(allslices(val_x,:,:),ys,zs);
		image(oneslicex)%,'Erasemode','none') 
  	   title('X slice');
		xlabel('z-axis');
      ylabel('y-axis');
		l=line([val_z,val_z],[1,ys]);set(l,'Color',[1 1 0])
		l=line([1,zs],[val_y,val_y]);set(l,'Color',[1 1 0])
      

	subplot(2,2,3)
		oneslicey=reshape(allslices(:,val_y,:),xs,zs)';
      image(oneslicey)%,'Erasemode','none') 
		title('Y slice');
		xlabel('x-axis');
		ylabel('z-axis');
	   l=line([val_x,val_x],[1,zs]);set(l,'Color',[1 1 0])
      l=line([1,xs],[val_z,val_z]);set(l,'Color',[1 1 0])


% Change the displayed value accordingly
set(findobj('Tag','text_slider_X'),'String',['X= ' num2str(val_x)]);

set(findobj('Tag','text_slider_Y'),'String',['Y= ' num2str(val_y)]);

set(findobj('Tag','text_slider_Z'),'String',['Z= ' num2str(val_z)]);

% DO IT!
drawnow;
