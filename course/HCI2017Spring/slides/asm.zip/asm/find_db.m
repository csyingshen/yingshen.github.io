function db=find_db(dx,P);
%function db=find_db(dx,P);


% find db by transforming dx into the model parameter space
%        db  = P\dx

db=P\dx;
