function Y=LimitTheJump(X);
%function Y=LimitTheJump(X);

DELTA=1;
DMAX=10;
loc1=find(abs(X)<DELTA);
X(loc1)=0;
loc2=find(abs(X)>DMAX);
X(loc2)=0.5*DMAX;
loc3=setdiff([1:size(X,1)],union(loc1,loc2));
X(loc3)=0.5*X(loc3);
Y=X;

