function MaxNumPyramidLevels=GetMaxNumPyramidLevels(TrnImgFiles);
%function MaxNumPyramidLevels=GetMaxNumPyramidLevels(TrnImgFiles);

%MULTI RESOLUTION ADDITTION -- get max needed levels
levels=100*ones(length(TrnImgFiles),1);
for ind1=1:length(TrnImgFiles),%for each image   
   ImgFile=TrnImgFiles{ind1};
   Img=imread(ImgFile);
   levels(ind1)=GetNumPyramidLevels(size(Img));
end
MaxNumPyramidLevels=min(levels);
% Modif XT 011112
%MaxNumPyramidLevels=1;
%the least number of levels determines the max allowed levels
