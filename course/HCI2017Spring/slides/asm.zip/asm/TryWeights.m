function TerminateNotContinue=TryWeights(MeanShape,tEigenvectors,ContoursEndingPoints);
%function TerminateNotContinue=TryWeights(MeanShape,tEigenvectors,ContoursEndingPoints);

t=size(tEigenvectors,2);
prompt=cell(1,t);
def   =cell(1,t);
for ind1=1:t
   prompt{ind1}=['Enter weighting factor No.',num2str(ind1)];
   def{ind1}='0';
% test   
%def{ind1}=num2str(0);
end

TheTitle='ASM: Trying differnt weights';
lineNo=1;
ButtonName='Yes';
while ButtonName=='Yes',
   answer=inputdlg(prompt,TheTitle,lineNo,def,'on');
   if isempty(answer) TerminateNotContinue = 1;  return;    end
   b=zeros(t,1);
   for ind1=1:t  
      b(ind1)=str2num(answer{ind1});
   end  
   Xtest=MeanShape + tEigenvectors*b;
   figure
   PlotShapes(Xtest,['ASM: test shape with b = [',num2str(b(:)'),']'],ContoursEndingPoints);
   
   ButtonName=questdlg('Do you want to try again?','ASM: Trying differnt weights');
   if(strcmp(ButtonName,'Cancel'))
      TerminateNotContinue = 1;
      return; 
   elseif (strcmp(ButtonName,'No'))
      TerminateNotContinue = 0;
      return;   
   end
end
