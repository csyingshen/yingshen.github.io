function [Xu,TrnImgFiles]=GetTrnSetCoor(NumTrnSetImgs,NumLandMarkPts)
%function Xu=GetTrnSetCoor(NumTrnSetImgs,NumLandMarkPts)

Xu=[];
ind1=1;
  
TrnImgFiles=cell(NumTrnSetImgs,1);

while ind1<=NumTrnSetImgs,
   FileName=0;
   PathName=0;  
   [FileName,PathName]=uigetfile('*.bmp',['ASM: Choose Image',...
                                  num2str(ind1),'/',num2str(NumTrnSetImgs)]);
   if FileName==0 Xu=0; return; end
   TrnImgFiles{ind1}=[PathName,FileName];
   Img=imread([PathName,FileName]);   
   
   [Y,X]=landmark(Img,['Labeling Image: ',num2str(ind1)],NumLandMarkPts);
   
   Xu=[Xu,[round(X);round(Y)]];
   ind1=ind1+1;
end
close;
