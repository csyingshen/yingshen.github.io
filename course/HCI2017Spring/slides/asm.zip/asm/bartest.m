Xu=rand(100,4);
MaxNumPyramidLevels=5;

hwtbar = waitbar(0,'Getting profiles. Please wait...');
for ind1=1:size(Xu,2),
   for ind1_2=1:MaxNumPyramidLevels,
      for ind2=1:size(Xu,1)/2,
         waitbar((ind1*ind1_2*ind2)/(size(Xu,2)*MaxNumPyramidLevels*size(Xu,1)/2));
      end
   end
end
close(hwtbar); 
