function  b=LimitTheB(b,tEigenValues);
%function  b=LimitTheB(b,tEigenValues);

LIM=3*sqrt(abs(tEigenValues));

tmpInd1=find(b>LIM);
b(tmpInd1)=LIM(tmpInd1);

tmpInd2=find(b<-LIM);
b(tmpInd2)=-LIM(tmpInd2);
