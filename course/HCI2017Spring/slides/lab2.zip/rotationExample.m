% Create a surface plot of the peaks function and return the surface handle.
figure
hSurface = surf(peaks(20));
% Rotate the surface plot 25 degrees around its x-axis.
direction = [1 0 0];
rotate(hSurface,direction,25)

% Create a surface plot of the peaks function and return the surface handle.
figure
hSurface = surf(peaks(20));
% Rotate the surface plot 25 degrees around its x-axis and y-axis.
direction = [1 1 0];
rotate(hSurface,direction,25)