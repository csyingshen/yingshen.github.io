figure
% cylinder returns thex-,y-, andz-coordinates of a cylinder with r=1. 
% The cylinder has 20 equally spaced points around its circumference
cylinder

% [X,Y,Z] = cylinder(r) returns the x-, y-, and z-coordinates of a cylinder
% using r to define a profile curve. cylinder treats each element in r as a
% radius at equally spaced heights along the unit height of the cylinder. 
% The cylinder has 20 equally spaced points around its circumference.
% This example generates a cylinder defined by the profile function 2+sin(t).
t = 0:pi/10:2*pi;
figure
[X,Y,Z] = cylinder(2+cos(t));
surf(X,Y,Z)
axis square