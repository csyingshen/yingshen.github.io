% ellipsoid(xc,yc,zc,xr,yr,zr,n) plot an ellipsoid with center (xc,yc,zc) 
% and semi-axis lengths (xr,yr,zr)
[x, y, z] = ellipsoid(0,0,0,5.9,3.25,3.25,30);
surf(x, y, z)
axis vis3d
