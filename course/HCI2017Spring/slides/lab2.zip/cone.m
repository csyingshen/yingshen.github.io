t = 1:-0.1:0;
angle = 0:0.1:2*pi;
x = cos(angle);
y = sin(angle);
[X,Y,Z] = cylinder(t);
surf(X,Y,Z);
hold on
fill(x,y,'b');