I = imread('earth.jpg'); % you can also try earth_light.jpg
I = flip(I, 1);
[x,y,z] = sphere(100);
rotate3d on
surf(x,y,z, 'FaceColor', 'texturemap', 'CData', I, 'EdgeColor', 'none')
axis vis3d
hold on
