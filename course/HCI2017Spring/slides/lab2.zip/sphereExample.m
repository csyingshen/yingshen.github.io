figure
% generates a sphere consisting of 20-by-20 faces
sphere
% generates a sphere consisting of 100-by-100 faces.
figure
sphere(100);

% generates another sphere consisting of 20-by-20 faces
[x,y,z] = sphere;
figure
surf(x,y,z)

hold on
surf(x+3,y-2,z) % centered at (3,-2,0)
surf(x,y+1,z-3) % centered at (0,1,-3)
