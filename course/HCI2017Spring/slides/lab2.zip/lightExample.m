[x, y, z] = ellipsoid(0,0,0,5.9,3.25,3.25,30);
surf(x, y, z)
axis vis3d
% light('Position',[-100 0 0],'Style','local')