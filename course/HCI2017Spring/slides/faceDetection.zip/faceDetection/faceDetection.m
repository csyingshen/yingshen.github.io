faceDetector = vision.CascadeObjectDetector();
for i=1:3
    img = imread(['faces' num2str(i) '.jpg']);
    bboxes = step(faceDetector, img); %faceDetector.step(I);
    IFaces = insertObjectAnnotation(img, 'rectangle', bboxes, 'Face');
    figure, imshow(IFaces), title('Detected faces');
end
